It is highly recommended to use only the necessary ASM jars for your
application instead of using the asm-all jar, unless you really need
all ASM packages.